Sample README.txt

Eventually your report about how you implemented thread synchronization
in the server should go here



Joanna did the sender part in MS1, and implemented the entirety of the main and server.cpp

Lucas did the receiver part in MS1, and implemented room.cpp and the message queue

Both of us styled/cleaned up our parts of the code separately.


[insert thread synchronization data]
